package tech.elegal.dietas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import tech.elegal.dietas.dao.AlimentoDAO;
import tech.elegal.dietas.dao.DietaDAO;
import tech.elegal.dietas.model.*;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;


@Controller
public class DietaController {

    private final DietaDAO dietaDao;
    private final AlimentoDAO alimentoDao;

    @Autowired
    public DietaController(DietaDAO dietaDao, AlimentoDAO alimentoDao) {
        this.dietaDao = dietaDao;
        this.alimentoDao = alimentoDao;
    }

    @GetMapping(value = "/dieta")
    public String dieta(HttpSession session, Model model) {
        var pacienteSession = (Paciente) session.getAttribute("paciente");
        if (pacienteSession == null)
            return "autenticacao";

        List<Dieta> dietas = dietaDao.findAllByIdPaciente(pacienteSession.getIdPaciente());
        if (dietas.isEmpty())
            return "objetivo";

        var desjejumAlimentos = new ArrayList<Alimento>();
        var lancheManhaAlimentos = new ArrayList<Alimento>();
        var almocoAlimentos = new ArrayList<Alimento>();
        var lancheTardeAlimentos = new ArrayList<Alimento>();
        var jantarAlimentos = new ArrayList<Alimento>();
        var ceiaAlimentos = new ArrayList<Alimento>();

        for (final var dieta : dietas) {
            var alimento = alimentoDao.getOne(dieta.getIdAlimento());
            if (dieta.getIdRefeicao() == Refeicao.DESJEJUM.getId())
                desjejumAlimentos.add(alimento);
            else if (dieta.getIdRefeicao() == Refeicao.LANCHE_MANHA.getId())
                lancheManhaAlimentos.add(alimento);
            else if (dieta.getIdRefeicao() == Refeicao.ALMOCO.getId())
                almocoAlimentos.add(alimento);
            else if (dieta.getIdRefeicao() == Refeicao.LANCHE_TARDE.getId())
                lancheTardeAlimentos.add(alimento);
            else if (dieta.getIdRefeicao() == Refeicao.JANTAR.getId())
                jantarAlimentos.add(alimento);
            else if (dieta.getIdRefeicao() == Refeicao.CEIA.getId())
                ceiaAlimentos.add(alimento);
        }

        var dto = new RefeicaoAlimentoDTO();
        dto.setDesjejumAlimentos(desjejumAlimentos);
        dto.setLancheManhaAlimentos(lancheManhaAlimentos);
        dto.setAlmocoAlimentos(almocoAlimentos);
        dto.setLancheTardeAlimentos(lancheTardeAlimentos);
        dto.setJantarAlimentos(jantarAlimentos);
        dto.setCeiaAlimentos(ceiaAlimentos);

        model.addAttribute("refeicao", dto);

        return "dieta";
    }


}

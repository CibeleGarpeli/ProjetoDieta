package tech.elegal.dietas.model;

import java.util.ArrayList;

public class RefeicaoAlimentoDTO {

    public RefeicaoAlimentoDTO() {
        this.desjejumAlimentos = new ArrayList<>();
        this.lancheManhaAlimentos = new ArrayList<>();
        this.almocoAlimentos = new ArrayList<>();
        this.lancheTardeAlimentos = new ArrayList<>();
        this.jantarAlimentos = new ArrayList<>();
        this.ceiaAlimentos = new ArrayList<>();
    }

    private ArrayList<Alimento> desjejumAlimentos;
    private ArrayList<Alimento> lancheManhaAlimentos;
    private ArrayList<Alimento> almocoAlimentos;
    private ArrayList<Alimento> lancheTardeAlimentos;
    private ArrayList<Alimento> jantarAlimentos;
    private ArrayList<Alimento> ceiaAlimentos;

    public ArrayList<Alimento> getDesjejumAlimentos() {
        return desjejumAlimentos;
    }

    public void setDesjejumAlimentos(ArrayList<Alimento> desjejumAlimentos) {
        this.desjejumAlimentos = desjejumAlimentos;
    }

    public ArrayList<Alimento> getLancheManhaAlimentos() {
        return lancheManhaAlimentos;
    }

    public void setLancheManhaAlimentos(ArrayList<Alimento> lancheManhaAlimentos) {
        this.lancheManhaAlimentos = lancheManhaAlimentos;
    }

    public ArrayList<Alimento> getAlmocoAlimentos() {
        return almocoAlimentos;
    }

    public void setAlmocoAlimentos(ArrayList<Alimento> almocoAlimentos) {
        this.almocoAlimentos = almocoAlimentos;
    }

    public ArrayList<Alimento> getLancheTardeAlimentos() {
        return lancheTardeAlimentos;
    }

    public void setLancheTardeAlimentos(ArrayList<Alimento> lancheTardeAlimentos) {
        this.lancheTardeAlimentos = lancheTardeAlimentos;
    }

    public ArrayList<Alimento> getJantarAlimentos() {
        return jantarAlimentos;
    }

    public void setJantarAlimentos(ArrayList<Alimento> jantarAlimentos) {
        this.jantarAlimentos = jantarAlimentos;
    }

    public ArrayList<Alimento> getCeiaAlimentos() {
        return ceiaAlimentos;
    }

    public void setCeiaAlimentos(ArrayList<Alimento> ceiaAlimentos) {
        this.ceiaAlimentos = ceiaAlimentos;
    }
}

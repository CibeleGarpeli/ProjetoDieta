package tech.elegal.dietas.model;

import javax.persistence.*;

@Entity
//@Table(name = "faixa_etaria", schema = "dbo", catalog = "Dietas")
public class FaixaEtaria {
    private Byte idFaixaEtaria;
    private String nome;

    @Id
    @Column
    public Byte getIdFaixaEtaria() {
        return idFaixaEtaria;
    }

    public void setIdFaixaEtaria(Byte idFaixaEtaria) {
        this.idFaixaEtaria = idFaixaEtaria;
    }

    @Basic
    @Column
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}

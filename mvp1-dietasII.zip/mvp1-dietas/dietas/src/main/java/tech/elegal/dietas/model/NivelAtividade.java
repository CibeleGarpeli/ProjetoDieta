package tech.elegal.dietas.model;

import javax.persistence.*;

@Entity
//@Table(name = "nivel_atividade", schema = "dbo", catalog = "Dietas")
public class NivelAtividade {
    private Byte idNivelAtividade;
    private String nome;

    @Id
    @Column
    public Byte getIdNivelAtividade() {
        return idNivelAtividade;
    }

    public void setIdNivelAtividade(Byte idNivelAtividade) {
        this.idNivelAtividade = idNivelAtividade;
    }

    @Basic
    @Column
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}

package tech.elegal.dietas.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;
import tech.elegal.dietas.model.Dieta;

import java.util.List;

public interface DietaDAO extends JpaRepository<Dieta, Integer> {
    @Transactional
    void deleteByIdPaciente(Integer id);

    List<Dieta> findAllByIdPaciente(Integer id);
}

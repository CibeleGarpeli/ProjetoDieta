package tech.elegal.dietas.services;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class EmailAuth extends Authenticator {
    private String username = "contato.appdietas@gmail.com";
    private String password = "#@ppDietas2020#";

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(username, password);
    }
}
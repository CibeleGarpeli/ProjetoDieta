package tech.elegal.dietas.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.elegal.dietas.model.DietaPadrao;

import java.util.List;

public interface DietaPadraoDAO extends JpaRepository<DietaPadrao, Integer> {
    List<DietaPadrao> findAllByKcal(Integer kcal);
}

package tech.elegal.dietas.model;

import javax.persistence.*;

@Entity
public class Alimento {
    private Integer idAlimento;
    private Integer idGrupoAlimento;
    private String nome;
    private Double peso;
    private Integer kcal;
    private Integer quantidade;
    private String medida;
    private Boolean desjejum;
    private Boolean lancheManha;
    private Boolean almoco;
    private Boolean lancheTarde;
    private Boolean jantar;
    private Boolean ceia;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getIdAlimento() {
        return idAlimento;
    }

    public void setIdAlimento(Integer idAlimento) {
        this.idAlimento = idAlimento;
    }

    @Basic
    @Column
    public Integer getIdGrupoAlimento() {
        return idGrupoAlimento;
    }

    public void setIdGrupoAlimento(Integer idGrupoAlimento) {
        this.idGrupoAlimento = idGrupoAlimento;
    }

    @Basic
    @Column
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Basic
    @Column
    public Double getPeso() {
        return peso;
    }

    public void setPeso(Double peso) {
        this.peso = peso;
    }

    @Basic
    @Column
    public Integer getKcal() {
        return kcal;
    }

    public void setKcal(Integer kcal) {
        this.kcal = kcal;
    }

    @Basic
    @Column
    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    @Basic
    @Column
    public String getMedida() {
        return medida;
    }

    public void setMedida(String medida) {
        this.medida = medida;
    }

    @Basic
    @Column
    public Boolean getDesjejum() {
        return desjejum;
    }

    public void setDesjejum(Boolean desjejum) {
        this.desjejum = desjejum;
    }

    @Basic
    @Column
    public Boolean getLancheManha() {
        return lancheManha;
    }

    public void setLancheManha(Boolean lancheManha) {
        this.lancheManha = lancheManha;
    }

    @Basic
    @Column
    public Boolean getAlmoco() {
        return almoco;
    }

    public void setAlmoco(Boolean almoco) {
        this.almoco = almoco;
    }

    @Basic
    @Column
    public Boolean getLancheTarde() {
        return lancheTarde;
    }

    public void setLancheTarde(Boolean lancheTarde) {
        this.lancheTarde = lancheTarde;
    }

    @Basic
    @Column
    public Boolean getJantar() {
        return jantar;
    }

    public void setJantar(Boolean jantar) {
        this.jantar = jantar;
    }

    @Basic
    @Column
    public Boolean getCeia() {
        return ceia;
    }

    public void setCeia(Boolean ceia) {
        this.ceia = ceia;
    }
}

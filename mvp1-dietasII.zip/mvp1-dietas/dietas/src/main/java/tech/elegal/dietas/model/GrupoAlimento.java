package tech.elegal.dietas.model;

import javax.persistence.*;

@Entity
//@Table(name = "grupo_alimento", schema = "dbo", catalog = "Dietas")
public class GrupoAlimento {
    private Byte idGrupoAlimento;
    private String nome;
    private Byte valorCalorico;

    @Id
    @Column
    public Byte getIdGrupoAlimento() {
        return idGrupoAlimento;
    }

    public void setIdGrupoAlimento(Byte idGrupoAlimento) {
        this.idGrupoAlimento = idGrupoAlimento;
    }

    @Basic
    @Column
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Basic
    @Column
    public Byte getValorCalorico() {
        return valorCalorico;
    }

    public void setValorCalorico(Byte valorCalorico) {
        this.valorCalorico = valorCalorico;
    }
}

package tech.elegal.dietas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import tech.elegal.dietas.dao.PacienteDAO;
import tech.elegal.dietas.model.Paciente;

import javax.servlet.http.HttpSession;

@Controller
public class AutenticacaoController {

    private final PacienteDAO pacienteDao;

    @Autowired
    public AutenticacaoController(PacienteDAO pacienteDao) {
        this.pacienteDao = pacienteDao;
    }

    @GetMapping("/autenticacao")
    public String autenticacao() {
        return "autenticacao";
    }

    @PostMapping("/login")
    public String login(Paciente dto, HttpSession session, Model model) {
        Paciente paciente = pacienteDao.findByEmailAndSenha(dto.getEmail(), dto.getSenha());

        if (paciente != null) {
            session.setAttribute("paciente", paciente);
            return "redirect:/";
        }

        model.addAttribute("mensagem", "conta não encontrada.");

        return "autenticacao";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.removeAttribute("paciente");
        return "autenticacao";
    }
}
package tech.elegal.dietas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import tech.elegal.dietas.dao.DietaDAO;
import tech.elegal.dietas.dao.PacienteDAO;
import tech.elegal.dietas.model.Paciente;
import tech.elegal.dietas.services.EmailService;

import javax.servlet.http.HttpSession;

@Controller
public class ContaController {

    private final PacienteDAO pacienteDao;
    private final DietaDAO dietaDao;

    @Autowired
    public ContaController(PacienteDAO pacienteDao, DietaDAO dietaDao) {
        this.pacienteDao = pacienteDao;
        this.dietaDao = dietaDao;
    }

    @GetMapping(value = "/conta")
    public String conta() {
        return "conta";
    }

    @PostMapping(value = "/salvarConta")
    public String salvarConta(Paciente paciente) {
        if (paciente.getSenha().isEmpty() || paciente.getNome().isEmpty() || paciente.getEmail().isEmpty())
            return "conta";

        Paciente entity = pacienteDao.findByEmail(paciente.getEmail());
        if (entity != null)
            return "conta";

        pacienteDao.save(paciente);

        return "autenticacao";
    }

    @GetMapping(value = "/recuperarSenha")
    public String recuperarSenha() {
        return "recuperar_senha";
    }

    @PostMapping(value = "/reenviarSenha")
    public String reenviarSenha(Paciente paciente, Model model) {
        Paciente entity = pacienteDao.findByEmail(paciente.getEmail());
        if (entity == null) {
            model.addAttribute("mensagem", "O email informado não existe.");
            return "recuperar_senha";
        }

        EmailService service = new EmailService();
        service.enviarEmail("contato.appdietas@gmail.com", entity.getEmail(),
                "Recuperação de Senha", "A sua senha é: " + entity.getSenha());

        return "autenticacao";
    }

    @GetMapping(value = "/alteracaoConta")
    public String alteracaoConta() {
        return "alteracao_conta";
    }

    @PostMapping(value = "/atualizarConta")
    public String atualizarConta(Paciente paciente, HttpSession session, Model model, boolean exclusao) {
        Paciente pacienteSession = (Paciente) session.getAttribute("paciente");
        if (pacienteSession == null)
            return "autenticacao";

        if (exclusao) {
            dietaDao.deleteByIdPaciente(pacienteSession.getIdPaciente());
            pacienteDao.deleteById(pacienteSession.getIdPaciente());
            return "autenticacao";
        }

        if (!pacienteSession.getEmail().equalsIgnoreCase(paciente.getEmail())) {
            Paciente pacientePersistido = pacienteDao.findByEmail(paciente.getEmail());
            if (pacientePersistido != null){
                model.addAttribute("msgAlerta", "Já existe um usuário com o e-mail informado.");
                return "alteracao_conta";
            }
        }

        pacienteSession.setNome(paciente.getNome());
        pacienteSession.setEmail(paciente.getEmail());
        pacienteSession.setSenha(paciente.getSenha());

        pacienteDao.save(pacienteSession);

        session.setAttribute("paciente", pacienteSession);
        model.addAttribute("msgSucesso", "Paciente atualizado com sucesso.");

        return "alteracao_conta";
    }
}

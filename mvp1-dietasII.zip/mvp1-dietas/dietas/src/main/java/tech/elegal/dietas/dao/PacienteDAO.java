package tech.elegal.dietas.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.elegal.dietas.model.Paciente;

public interface PacienteDAO extends JpaRepository<Paciente, Integer> {
    Paciente findByEmail(String email);
    Paciente findByEmailAndSenha(String email, String senha);
}

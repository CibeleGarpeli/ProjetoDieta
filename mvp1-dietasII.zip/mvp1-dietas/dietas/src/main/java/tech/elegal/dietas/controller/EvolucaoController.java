package tech.elegal.dietas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import tech.elegal.dietas.dao.AlimentoDAO;
import tech.elegal.dietas.dao.DietaDAO;
import tech.elegal.dietas.dao.PacienteDAO;
import tech.elegal.dietas.model.Dieta;
import tech.elegal.dietas.model.Paciente;
import tech.elegal.dietas.model.Refeicao;
import tech.elegal.dietas.model.RefeicaoAlimentoDTO;

import javax.servlet.http.HttpSession;
import java.util.List;


@Controller
public class EvolucaoController {

    private final DietaDAO dietaDao;
    private final AlimentoDAO alimentoDao;
    private PacienteDAO pacienteDao;

    @Autowired
    public EvolucaoController(DietaDAO dietaDao, AlimentoDAO alimentoDao, PacienteDAO pacienteDao) {
        this.dietaDao = dietaDao;
        this.alimentoDao = alimentoDao;
        this.pacienteDao = pacienteDao;
    }


    @RequestMapping("/")
    public String evolucao(HttpSession session, Model model) {
        Paciente pacienteSession = (Paciente) session.getAttribute("paciente");
        if (pacienteSession == null)
            return "autenticacao";

        if (pacienteSession.getVet() == null || pacienteSession.getVet() == 0)
            return "objetivo";

        atribuirCaloriasPorRefeicao(pacienteSession, model);

        return "evolucao";
    }


   public void atribuirCaloriasPorRefeicao(Paciente pacienteSession, Model model) {

        List<Dieta> dietaList = dietaDao.findAllByIdPaciente(pacienteSession.getIdPaciente());

        Integer desjejumCalorias = 0;
        Integer lancheManhaCalorias = 0;
        Integer almocoCalorias = 0;
        Integer lancheTardeCalorias = 0;
        Integer jantarCalorias = 0;
        Integer ceiaCalorias = 0;

        for (final var dieta : dietaList) {
            var alimento = alimentoDao.getOne(dieta.getIdAlimento());

            if (dieta.getIdRefeicao() == Refeicao.DESJEJUM.getId())
                desjejumCalorias += alimento.getKcal();
            else if (dieta.getIdRefeicao() == Refeicao.LANCHE_MANHA.getId())
                lancheManhaCalorias += alimento.getKcal();
            else if (dieta.getIdRefeicao() == Refeicao.ALMOCO.getId())
                almocoCalorias +=alimento.getKcal();
            else if (dieta.getIdRefeicao() == Refeicao.LANCHE_TARDE.getId())
                lancheTardeCalorias += alimento.getKcal();
            else if (dieta.getIdRefeicao() == Refeicao.JANTAR.getId())
                jantarCalorias += alimento.getKcal();
            else if (dieta.getIdRefeicao() == Refeicao.CEIA.getId())
                ceiaCalorias += alimento.getKcal();
        }

        model.addAttribute("desjejumCalorias", desjejumCalorias);
        model.addAttribute("lancheManhaCalorias", lancheManhaCalorias);
        model.addAttribute("almocoCalorias", almocoCalorias);
        model.addAttribute("lancheTardeCalorias", lancheTardeCalorias);
        model.addAttribute("jantarCalorias", jantarCalorias);
        model.addAttribute("ceiaCalorias", ceiaCalorias);
    }

}

package tech.elegal.dietas.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.elegal.dietas.model.Alimento;

public interface AlimentoDAO extends JpaRepository<Alimento, Integer> {
}

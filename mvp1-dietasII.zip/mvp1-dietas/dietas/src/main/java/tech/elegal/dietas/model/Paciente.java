package tech.elegal.dietas.model;

import javax.persistence.*;

@Entity
public class Paciente {
    private Integer idPaciente;
    private Integer idNivelAtividade;
    private Integer idSexo;
    private String nome;
    private String email;
    private String senha;
    private Double pesoAtual;
    private Double pesoDesejado;
    private Integer altura;
    private Integer idade;
    private Double vet;
    private Double imc;
    private Double agua;
    private Double meta;
    private String textoMeta;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(Integer idPaciente) {
        this.idPaciente = idPaciente;
    }

    @Basic
    @Column
    public Integer getIdNivelAtividade() {
        return idNivelAtividade;
    }

    public void setIdNivelAtividade(Integer idNivelAtividade) {
        this.idNivelAtividade = idNivelAtividade;
    }

    @Basic
    @Column
    public Integer getIdSexo() {
        return idSexo;
    }

    public void setIdSexo(Integer idSexo) {
        this.idSexo = idSexo;
    }

    @Basic
    @Column
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Basic
    @Column
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column
    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    @Basic
    @Column
    public Double getPesoAtual() {
        return pesoAtual;
    }

    public void setPesoAtual(Double pesoAtual) {
        this.pesoAtual = pesoAtual;
    }

    @Basic
    @Column
    public Double getPesoDesejado() {
        return pesoDesejado;
    }

    public void setPesoDesejado(Double pesoDesejado) {
        this.pesoDesejado = pesoDesejado;
    }

    @Basic
    @Column
    public Integer getAltura() {
        return altura;
    }

    public void setAltura(Integer altura) {
        this.altura = altura;
    }

    @Basic
    @Column
    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }

    @Basic
    @Column
    public Double getVet() {
        return vet;
    }

    public void setVet(Double vet) {
        this.vet = vet;
    }

    @Basic
    @Column
    public Double getImc() {return imc;}

    public void setImc(Double imc) { this.imc = imc; }

    @Basic
    @Column
    public Double getAgua() {
        return agua;
    }

    public void setAgua(Double agua) {
        this.agua = agua;
    }

    @Basic
    @Column
    public Double getMeta() {
        return meta;
    }

    public void setMeta(Double meta) {
        this.meta = meta;
    }

    @Basic
    @Column
    public String getTextoMeta() {
        return textoMeta;
    }

    public void setTextoMeta(String textoMeta) {
        this.textoMeta = textoMeta;
    }


    // todo: buscar da tabela o fator atividade
    public double obterFatorAtividade() {
        switch (idNivelAtividade){
            case 1:
                return 1.5;
            case 2:
                return 1.8;
            default:
                return 2.1;
        }
    }

    public void calcularValorEnergeticoTotal() {
        if (this.idSexo == 1)
            vet = (655.0955 + (9.5634 * pesoDesejado) + (1.8496 * altura) - (4.6756 * idade)) * obterFatorAtividade();
        else if (this.idSexo == 2)
            vet = (66.4730 + (13.7516 * pesoDesejado) + (5.0033 * altura) - (6.7559 * idade)) * obterFatorAtividade();
    }

    public void calcularIMC(){
        this.imc = pesoAtual/(altura*altura)*10000;
    }

    public void calcularAgua(){
        if (this.idSexo == 1 && this.idade < 13){
            agua = 2.400;
        } else if (this.idSexo == 1 && this.idade > 14 && this.idade <=18){
            agua = 3.300;
        }else if (this.idSexo == 1 && this.idade > 19 ){
            agua = 3.700;
        }else if (this.idSexo == 2 && this.idade < 13){
            agua = 2.100;
        } else if (this.idSexo == 2 && this.idade > 14 && this.idade <=18){
            agua = 2.300;
        }else if (this.idSexo == 2 && this.idade > 19 ){
            agua = 2.700;
        }
    }

    public void calcularMeta(){
        if (this.pesoAtual.doubleValue() == this.pesoDesejado.doubleValue()){
            meta = pesoAtual;
        } else if (this.pesoAtual.doubleValue() != this.pesoDesejado.doubleValue()){
            meta = pesoDesejado  - pesoAtual;
        }
    }

    public void retornaTextoMeta(){
        if (this.meta.doubleValue() == this.pesoAtual.doubleValue()){
            this.textoMeta = "Manter " + meta + " kg";
        }else if (this.meta.doubleValue() != this.pesoAtual.doubleValue() && this.meta > 0){
            this.textoMeta = "Ganhar " + meta + " kg";
        }else if (this.meta.doubleValue() != this.pesoAtual.doubleValue() && this.meta < 0){
            this.textoMeta = "Perder " + Math.abs(meta) + " kg";
        }
    }

    public Integer obterNecessidadeCalorica() {
        Integer kcal;

        if (vet >= 1600 && vet < 1800)
            kcal = 1600;
        else if (vet >= 1800 && vet < 2000)
            kcal = 1800;
        else if (vet >= 2000 && vet < 2200)
            kcal = 1800;
        else if (vet >= 2200 && vet < 2400)
            kcal = 2200;
        else if (vet >= 2400 && vet < 2600)
            kcal = 2400;
        else if (vet >= 2600 && vet < 2800)
            kcal = 2600;
        else if (vet >= 2800 && vet < 3000)
            kcal = 2800;
        else
            kcal = 3000;

        return kcal;
    }
}

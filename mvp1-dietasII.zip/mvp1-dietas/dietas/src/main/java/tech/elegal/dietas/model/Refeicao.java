package tech.elegal.dietas.model;

public enum Refeicao {
    DESJEJUM(1),
    LANCHE_MANHA(2),
    ALMOCO(3),
    LANCHE_TARDE(4),
    JANTAR(5),
    CEIA(6);

    private int id;

    Refeicao(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
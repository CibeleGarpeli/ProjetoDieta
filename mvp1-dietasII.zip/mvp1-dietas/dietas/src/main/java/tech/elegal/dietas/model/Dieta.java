package tech.elegal.dietas.model;

import javax.persistence.*;

@Entity
public class Dieta {
    private Integer idDieta;
    private Integer idPaciente;
    private Integer idRefeicao;
    private Integer idAlimento;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getIdDieta() {
        return idDieta;
    }

    public void setIdDieta(Integer idDieta) {
        this.idDieta = idDieta;
    }

    @Basic
    @Column
    public Integer getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(Integer idPaciente) {
        this.idPaciente = idPaciente;
    }

    @Basic
    @Column
    public Integer getIdRefeicao() {
        return idRefeicao;
    }

    public void setIdRefeicao(Integer idRefeicao) {
        this.idRefeicao = idRefeicao;
    }

    @Basic
    @Column
    public Integer getIdAlimento() {
        return idAlimento;
    }

    public void setIdAlimento(Integer idAlimento) {
        this.idAlimento = idAlimento;
    }
}

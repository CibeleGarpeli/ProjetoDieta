package tech.elegal.dietas.model;

import javax.persistence.*;

@Entity
//@Table(name = "dieta_padrao", schema = "dbo", catalog = "Dietas")
public class DietaPadrao {
    private Integer idDietaPadrao;
    private Integer idRefeicao;
    private Integer idAlimento;
    private Integer kcal;

    @Id
    @Column
    public Integer getIdDietaPadrao() {
        return idDietaPadrao;
    }

    public void setIdDietaPadrao(Integer idDietaPadrao) {
        this.idDietaPadrao = idDietaPadrao;
    }

    @Basic
    @Column
    public Integer getIdRefeicao() {
        return idRefeicao;
    }

    public void setIdRefeicao(Integer idRefeicao) {
        this.idRefeicao = idRefeicao;
    }

    @Basic
    @Column
    public Integer getIdAlimento() {
        return idAlimento;
    }

    public void setIdAlimento(Integer idAlimento) {
        this.idAlimento = idAlimento;
    }

    @Basic
    @Column
    public Integer getKcal() {
        return kcal;
    }

    public void setKcal(Integer kcal) {
        this.kcal = kcal;
    }
}

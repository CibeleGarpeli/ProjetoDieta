package tech.elegal.dietas.model;

import javax.persistence.*;

@Entity
//@Table(name = "fator_atividade", schema = "dbo", catalog = "Dietas")
public class FatorAtividade {
    private Integer idFatorAtividade;
    private Byte faixaEtaria;
    private Byte idSexo;
    private Double leve;
    private Double moderada;
    private Double intensa;

    @Id
    @Column
    public Integer getIdFatorAtividade() {
        return idFatorAtividade;
    }

    public void setIdFatorAtividade(Integer idFatorAtividade) {
        this.idFatorAtividade = idFatorAtividade;
    }

    @Basic
    @Column
    public Byte getFaixaEtaria() {
        return faixaEtaria;
    }

    public void setFaixaEtaria(Byte faixaEtaria) {
        this.faixaEtaria = faixaEtaria;
    }

    @Basic
    @Column
    public Byte getIdSexo() {
        return idSexo;
    }

    public void setIdSexo(Byte idSexo) {
        this.idSexo = idSexo;
    }

    @Basic
    @Column
    public Double getLeve() {
        return leve;
    }

    public void setLeve(Double leve) {
        this.leve = leve;
    }

    @Basic
    @Column
    public Double getModerada() {
        return moderada;
    }

    public void setModerada(Double moderada) {
        this.moderada = moderada;
    }

    @Basic
    @Column
    public Double getIntensa() {
        return intensa;
    }

    public void setIntensa(Double intensa) {
        this.intensa = intensa;
    }
}

package tech.elegal.dietas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import tech.elegal.dietas.dao.DietaDAO;
import tech.elegal.dietas.dao.DietaPadraoDAO;
import tech.elegal.dietas.dao.PacienteDAO;
import tech.elegal.dietas.model.Dieta;
import tech.elegal.dietas.model.DietaPadrao;
import tech.elegal.dietas.model.Paciente;

import javax.servlet.http.HttpSession;
import java.util.List;


@Controller
public class ObjetivoController {

    private final PacienteDAO pacienteDao;
    private final DietaPadraoDAO dietaPadraoDao;
    private final DietaDAO dietaDao;

    @Autowired
    public ObjetivoController(PacienteDAO pacienteDao, DietaPadraoDAO dietaPadraoDao, DietaDAO dietaDao) {
        this.pacienteDao = pacienteDao;
        this.dietaPadraoDao = dietaPadraoDao;
        this.dietaDao = dietaDao;
    }

    @GetMapping(value = "/objetivo")
    public String objetivo(HttpSession session) {
        Paciente pacienteSession = (Paciente) session.getAttribute("paciente");
        if (pacienteSession == null)
            return "autenticacao";

        return "objetivo";
    }

    @PostMapping(value = "/salvarObjetivo")
    public String salvarObjetivo(Paciente paciente, HttpSession session) {
        Paciente pacienteSession = (Paciente) session.getAttribute("paciente");
        if (pacienteSession == null)
            return "autenticacao";

        paciente.setIdPaciente(pacienteSession.getIdPaciente());
        paciente.setNome(pacienteSession.getNome());
        paciente.setEmail(pacienteSession.getEmail());
        paciente.setSenha(pacienteSession.getSenha());

        // Realiza o calculo do VET
        paciente.calcularValorEnergeticoTotal();

        //Realiza o calculo do IMC
        paciente.calcularIMC();

        //Realiza o calculo de Necessidade Hídrica
        paciente.calcularAgua();

        //Realiza o calculo da meta de perda/ganho de peso
        paciente.calcularMeta();

        //Retorna o texto da meta
        paciente.retornaTextoMeta();

        // Salva o paciente na base
        paciente = pacienteDao.save(paciente);

        // Cria a dieta para o paciente de acordo com dieta parametrizada.
        salvarDietaPaciente(paciente);

        // Atualizo a sessão com o paciente completo
        session.setAttribute("paciente", paciente);

        return "redirect:/dieta";
    }

    private void salvarDietaPaciente(Paciente paciente) {
        dietaDao.deleteByIdPaciente(paciente.getIdPaciente());

        List<DietaPadrao> dietasPadrao = dietaPadraoDao.findAllByKcal(paciente.obterNecessidadeCalorica());
        for (final DietaPadrao dietaPadrao : dietasPadrao) {
            Dieta dieta = new Dieta();
            dieta.setIdPaciente(paciente.getIdPaciente());
            dieta.setIdAlimento(dietaPadrao.getIdAlimento());
            dieta.setIdRefeicao(dietaPadrao.getIdRefeicao());

            dietaDao.save(dieta);
        }
    }
}

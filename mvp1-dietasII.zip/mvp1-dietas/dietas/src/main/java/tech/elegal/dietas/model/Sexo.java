package tech.elegal.dietas.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Sexo {
    private Byte idSexo;
    private String nome;

    @Id
    @Column
    public Byte getIdSexo() {
        return idSexo;
    }

    public void setIdSexo(Byte idSexo) {
        this.idSexo = idSexo;
    }

    @Basic
    @Column
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
